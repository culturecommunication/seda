/* ***** BEGIN LICENSE BLOCK *****
 *    Copyright 2010 Michel Jacobson michel.jacobson@gmail.com
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 * ***** END LICENSE BLOCK ***** */

/*-----------------------------------------------------------------------*/
package seda;

import java.util.*;
/*-----------------------------------------------------------------------*/

/** Gestion des libelles du programme.
*/
public class PreferencesResourceBundle  {
		private ResourceBundle         labels;

	/** Choix de la ressource de correspondances des libelles en fonction de la Locale.
	*/
	public PreferencesResourceBundle(Locale locale) {
		this.labels = ResourceBundle.getBundle ("resources/Toolkit", locale);
	}

	/**
	 * Retourne le label dans la langue de la locale.
	 * @param key     Label
	 **/
	public String getLocaliseString(String key) {
		if (labels!=null) {
			try {
				return labels.getString(key);
			} catch (NullPointerException e) {
				return "null";
			} catch (MissingResourceException e) {
				return key;
			} catch (ClassCastException e) {
				return "null";
			}
		} else {
			return key;
		}
	}

};
