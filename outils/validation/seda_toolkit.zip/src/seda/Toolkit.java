/* ***** BEGIN LICENSE BLOCK *****
 *    Copyright 2011 Michel Jacobson michel.jacobson@gmail.com
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 * ***** END LICENSE BLOCK ***** */

/*-----------------------------------------------------------------------*/
package seda;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import javax.swing.event.*;

import javax.xml.transform.*;
import javax.xml.transform.sax.*;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.XMLFilter;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;

import java.security.MessageDigest;
import java.security.DigestInputStream;

import org.apache.commons.codec.binary.Base64;

import com.thaiopensource.validate.ValidationDriver;
/*-----------------------------------------------------------------------*/

/********************************************************************
**   Programme de validation pour des messages de transferts au format du SEDA.
*********************************************************************/
public class Toolkit extends JFrame {
	private File                  current_file;
	private JTextPane             texte;
	public static PreferencesResourceBundle    LABELS;

	protected static final String EXTERNAL_SCHEMALOCATION      = "http://apache.org/xml/properties/schema/external-schemaLocation";
	protected static final String SCHEMA_VALIDATION_FEATURE_ID = "http://apache.org/xml/features/validation/schema";
	protected static final String DEFAULT_PARSER_NAME          = "org.apache.xerces.parsers.SAXParser";

	public static void main(String [] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				Toolkit thisClass = new Toolkit();
				thisClass.setVisible(true);
			}
		});
	}

	/********************************************************************
	**   Creation de la fenetre principale
	*********************************************************************/
	public Toolkit() {
		super();
		this.current_file = null;
		LABELS = new PreferencesResourceBundle(Locale.getDefault());

		setLayout(new BorderLayout() );
		addWindowListener (new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				quit();
			}
		});
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		Hashtable listMenuItems = new Hashtable();
		listMenuItems.put("menu",             "menu.file/menu.edit/menu.tools/menu.help");
		listMenuItems.put("menu.file",        "file.open/-/file.quit");
		listMenuItems.put("menu.edit",        "edit.copy/edit.clear");
		listMenuItems.put("menu.tools",       "tools.xml_validation/tools.seda_validation/tools.profil_validation/tools.schematron_validation/-/tools.transform/tools.hashcode_test");
		listMenuItems.put("menu.help",        "help.about");

		setTitle(LABELS.getLocaliseString("appName"));
		setBackground(Color.white);
		getContentPane().setLayout(new BorderLayout());

		/* Toolbars
		*/
		JToolBar toolBar = new JToolBar("Toolbar");
		JButton openButton = new JButton(new ImageIcon(getClass().getResource("/resources/img/fileopen.png")));
		openButton.setToolTipText(LABELS.getLocaliseString("file.open"));
		openButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				openSedaMessage();
			}
		});
		JButton copyButton = new JButton(new ImageIcon(getClass().getResource("/resources/img/editcopy.png")));
		copyButton.setToolTipText(LABELS.getLocaliseString("edit.copy"));
		copyButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				texte.copy();
			}
		});
		JButton clearButton = new JButton(new ImageIcon(getClass().getResource("/resources/img/editclear.png")));
		clearButton.setToolTipText(LABELS.getLocaliseString("edit.clear"));
		clearButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				texte.setText("");
			}
		});
    	toolBar.add(openButton);
    	toolBar.addSeparator();
    	toolBar.add(copyButton);
    	toolBar.add(clearButton);

		getContentPane().add(toolBar, BorderLayout.PAGE_START);

		JMenuBar mb = createMenubar(listMenuItems);
		JDesktopPane desktop = new JDesktopPane();
		setJMenuBar(mb);

		getContentPane().add(desktop, BorderLayout.CENTER);
        Dimension screenSize = new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize());
        screenSize.setSize(screenSize.getWidth() / 2, screenSize.getHeight() / 2);
		setSize(screenSize);
		texte = new JTextPane();
        texte.setEditable(false);

		try {
		    Console console = new Console(texte);
			desktop.add(console);
			try {
				console.setVisible(true);
				console.setSelected(true);
			} catch (java.beans.PropertyVetoException e) {
				e.printStackTrace();
			}
		} catch (IOException e) {
		}

	}

	/********************************************************************
	**   Quitter l'application
	*********************************************************************/
	private void quit() {
		dispose();
		System.exit(0);
	}

	/********************************************************************
	**   Creation de la bare des menus
	*********************************************************************/
	private JMenuBar createMenubar(Hashtable hash) {
		JMenuItem mi;
		JMenuBar mb = new JMenuBar();

		String liste = (String)hash.get("menu");
		StringTokenizer menuKeys = new StringTokenizer(liste, "/");
		while (menuKeys.hasMoreTokens()) {
			String name = menuKeys.nextToken();
			JMenu m = createMenu(name, hash);
			if (m != null) {
				mb.add(m);
			}
		}
		return mb;
	}

	/********************************************************************
	**   Creation du menu
	*********************************************************************/
	private JMenuItem createMenuItem(String cmd) {
		JMenuItem mi = new JMenuItem(LABELS.getLocaliseString(cmd));
		return mi;
	}

	/********************************************************************
	**   Creation du menu
	*********************************************************************/
	private JMenuItem createMenuItem(String cmd, Icon icon) {
		JMenuItem mi = createMenuItem(cmd);
		mi.setIcon(icon);
		return mi;
	}

	/********************************************************************
	**   Creation des menus
	*********************************************************************/
	private JMenu createMenu(String key, Hashtable hash) {
		final JMenu menu = new JMenu(LABELS.getLocaliseString(key));
		String s = (String)hash.get(key);
		StringTokenizer menuItems = new StringTokenizer(s, "/");
		while (menuItems.hasMoreTokens()) {
			String name = menuItems.nextToken();
			if (name.equals("-")) {
				menu.addSeparator();
			} else if (name.equals("file.open")) {
				final JMenuItem mi = createMenuItem(name, new ImageIcon(getClass().getResource("/resources/img/fileopen.png")));
				mi.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
				mi.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e) {
						openSedaMessage();
					}
				});
				menu.add(mi);
			} else if (name.equals("file.quit")) {
				final JMenuItem mi = createMenuItem(name);
				mi.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, ActionEvent.CTRL_MASK));
				mi.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e) {
						quit();
					}
				});
				menu.add(mi);
			} else if (name.equals("edit.copy")) {
				final JMenuItem mi = createMenuItem(name, new ImageIcon(getClass().getResource("/resources/img/editcopy.png")));
				mi.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.CTRL_MASK));
				mi.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e) {
						texte.copy();
					}
				});
				menu.add(mi);
			} else if (name.equals("edit.clear")) {
				final JMenuItem mi = createMenuItem(name, new ImageIcon(getClass().getResource("/resources/img/editclear.png")));
				mi.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e) {
						texte.setText("");
					}
				});
				menu.add(mi);
			} else if (name.equals("tools.xml_validation")) {
				final JMenuItem mi = createMenuItem(name);
				mi.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e) {
						if (current_file != null) {
							if (xml_validation()) {
								texte.insertIcon(new ImageIcon(getClass().getResource("/resources/img/greenled.png")));
								System.out.println(" Document XML bien forme");
							}
						} else {
							System.out.println("Ouvrir le fichier avant");
						}
					}
				});
				menu.add(mi);
			} else if (name.equals("tools.seda_validation")) {
				final JMenuItem mi = createMenuItem(name);
				mi.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e) {
						if (current_file != null) {
							if (seda_validation()) {
								texte.insertIcon(new ImageIcon(getClass().getResource("/resources/img/greenled.png")));
								System.out.println(" Message SEDA valide");
							}
						} else {
							System.out.println("Ouvrir le fichier avant");
						}
					}
				});
				menu.add(mi);
			} else if (name.equals("tools.profil_validation")) {
				final JMenuItem mi = createMenuItem(name);
				mi.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e) {
						if (current_file != null) {
							File rng = openProfil();
							if (rng != null) {
								if (profil_validation(rng))  {
									texte.insertIcon(new ImageIcon(getClass().getResource("/resources/img/greenled.png")));
									System.out.println(" Fichier valide, conforme au profil");
								}
							}
						} else {
							System.out.println("Ouvrir le fichier avant");
						}
					}
				});
				menu.add(mi);
			} else if (name.equals("tools.schematron_validation")) {
				final JMenuItem mi = createMenuItem(name);
				mi.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e) {
						if (current_file != null) {
							File schematron = openSchematron();
							if (schematron != null) {
								if (schematron_validation(schematron))  {
									texte.insertIcon(new ImageIcon(getClass().getResource("/resources/img/greenled.png")));
									System.out.println(" Le schematron ne retourne auncune erreur");
								}
							}
						} else {
							System.out.println("Ouvrir le fichier avant");
						}
					}
				});
				menu.add(mi);
			} else if (name.equals("tools.transform")) {
				final JMenuItem mi = createMenuItem(name);
				mi.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e) {
						if (current_file != null) {
							File xsl = openXSLT();
							if (xsl != null) {
								transform(xsl);
							}
						} else {
							System.out.println("Ouvrir le fichier avant");
						}
					}
				});
				menu.add(mi);
			} else if (name.equals("tools.hashcode_test")) {
				final JMenuItem mi = createMenuItem(name);
				mi.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e) {
						if (current_file != null) {
							if (hashcode_test()) {
								System.out.println(" Toutes les empreintes sont verifiees");
							} else {
								System.out.println(" Erreur dans la verification des empreintes");
							}
						} else {
							System.out.println("Ouvrir le fichier avant");
						}
					}
				});
				menu.add(mi);
			} else if (name.equals("help.about")) {
				final JMenuItem mi = createMenuItem(name);
				mi.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e) {
						about();
					}
				});
				menu.add(mi);
			}
		}
		return menu;
	}

	private String getFileName() {
		if (current_file != null) {
			String ficname = current_file.getName();
			return ficname.replaceFirst("\\..*$", "");
		} else {
			return "sans_titre";
		}
	}


	/********************************************************************
	**   Ouvre un projet existant
	*********************************************************************/
	private void openSedaMessage() {
		JFileChooser chooser = new JFileChooser(System.getProperty("user.dir"));
		MyFileFilter filter = new MyFileFilter();
		filter.addExtension("xml");
		filter.setDescription("XML Files");
		chooser.setFileFilter(filter);
		chooser.setDialogTitle("Open XML file");
		if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
			current_file = chooser.getSelectedFile();
			System.setProperty("user.dir",  chooser.getCurrentDirectory().getPath());
		}
	}
	/********************************************************************
	**   Ouvre un schema de profil
	*********************************************************************/
	private File openProfil() {
		JFileChooser chooser = new JFileChooser(System.getProperty("user.dir"));
		MyFileFilter filter = new MyFileFilter();
		filter.addExtension("rng");
		filter.setDescription("RelaxNG Files");
		chooser.setFileFilter(filter);
		chooser.setDialogTitle("Open RNG file");
		if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
			return chooser.getSelectedFile();
		}
		return null;
	}
	/********************************************************************
	**   Ouvre un schematron
	*********************************************************************/
	private File openSchematron() {
		JFileChooser chooser = new JFileChooser(System.getProperty("user.dir"));
		MyFileFilter filter = new MyFileFilter();
		filter.addExtension("sch");
		filter.setDescription("Schematron Files");
		chooser.setFileFilter(filter);
		chooser.setDialogTitle("Open SCH file");
		if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
			return chooser.getSelectedFile();
		}
		return null;
	}
	/********************************************************************
	**   Ouvre une feuille de styles xslt
	*********************************************************************/
	private File openXSLT() {
		JFileChooser chooser = new JFileChooser(System.getProperty("user.dir"));
		MyFileFilter filter = new MyFileFilter();
		filter.addExtension("xsl");
		filter.setDescription("XSLT Files");
		chooser.setFileFilter(filter);
		chooser.setDialogTitle("Open XSL file");
		if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
			return chooser.getSelectedFile();
		}
		return null;
	}

	/********************************************************************
	**   Test la bonne formation xml du fichier
	*********************************************************************/
	private boolean xml_validation() {
		boolean hadError = false;
		XMLReader parser = null;
		try {
			parser = XMLReaderFactory.createXMLReader();
			SedaErrorHandler sedaErrorHandler = new SedaErrorHandler();
			parser.setErrorHandler(sedaErrorHandler);
			try {
				parser.parse(new InputSource(new FileInputStream(current_file)));
			} catch (SAXParseException e) {
				//Deja pris en charge par le ErrorHandler
			} catch (Exception e) {
				System.out.println("Erreur du parser - "+e.getMessage());
			}
			hadError = sedaErrorHandler.hadError();
		} catch (Exception e) {
			hadError = true;
			System.out.println("Erreur: "+e+" - Impossible d'instancier le parser");
		}
		return !(hadError);
	}

	/********************************************************************
	**   Test la conformite du fichier au seda
	*********************************************************************/
	private boolean seda_validation() {
		boolean hadError = false;
		XMLReader parser = null;
		try {
			parser = XMLReaderFactory.createXMLReader();
			try {
				String schema = getClass().getResource("/resources/seda/seda_v1-0.xsd").toString();
				String schemaLocation = "fr:gouv:culture:archivesdefrance:seda:v1.0 "+schema;
				parser.setProperty(EXTERNAL_SCHEMALOCATION, schemaLocation);
			} catch (Exception e) {
				System.out.println("Alerte: Le parser ne peut definir ("+EXTERNAL_SCHEMALOCATION+")");
			}
			parser.setFeature("http://xml.org/sax/features/validation", true);
			try {
				parser.setFeature(SCHEMA_VALIDATION_FEATURE_ID, true);
			} catch (Exception e) {
				System.out.println("Alerte: Le parser ne supporte pas la fonction ("+SCHEMA_VALIDATION_FEATURE_ID+")");
			}
			SedaErrorHandler sedaErrorHandler = new SedaErrorHandler();
			SedaTransfertContentHandler sedaTransfertContentHandler = new SedaTransfertContentHandler();
			parser.setErrorHandler(sedaErrorHandler);
			parser.setContentHandler(sedaTransfertContentHandler);
			try {
				parser.parse(new InputSource(new FileInputStream(current_file)));
			} catch (SAXParseException e) {
				//Deja pris en charge par le ErrorHandler
			} catch (Exception e) {
				System.out.println("Erreur du parser - "+e.getMessage());
			}
			hadError = sedaErrorHandler.hadError();
		} catch (Exception e) {
			hadError = true;
			System.out.println("Erreur: "+e+" - Impossible d'instancier le parser");
		}
		return !(hadError);
	}
	/********************************************************************
	**   Teste la conformite au fichier schematron
	*********************************************************************/
	private boolean schematron_validation(File schematron) {
		boolean hadError = false;
		try {
			SAXParserFactory spf = SAXParserFactory.newInstance();
			spf.setNamespaceAware(true);
			XMLReader reader = spf.newSAXParser().getXMLReader();
			SAXTransformerFactory factory = (SAXTransformerFactory)TransformerFactory.newInstance();
			factory.setURIResolver(new MyUriResolver());
			Transformer transformer = factory.newTransformer();
			ByteArrayOutputStream writer = new ByteArrayOutputStream();

			//etape 1
			XMLFilter filtre1_1 = factory.newXMLFilter(new StreamSource(getClass().getResourceAsStream("/resources/schematron/iso_dsdl_include.xsl")));
			XMLFilter filtre1_2 = factory.newXMLFilter(new StreamSource(getClass().getResourceAsStream("/resources/schematron/iso_abstract_expand.xsl")));
			XMLFilter filtre1_3 = factory.newXMLFilter(new StreamSource(getClass().getResourceAsStream("/resources/schematron/iso_svrl_for_xslt1.xsl")));

			filtre1_1.setParent(reader);
			filtre1_2.setParent(filtre1_1);
			filtre1_3.setParent(filtre1_2);

			SAXSource source = new SAXSource(filtre1_3, new InputSource(new FileInputStream(schematron)));
			StreamResult resultat = new StreamResult(writer);

			transformer.transform(source, resultat);

			//recuperation du resulat
			byte[] content = writer.toByteArray();
			writer.reset();

			//etape 2
			XMLFilter filtre2_1 = factory.newXMLFilter(new StreamSource(new ByteArrayInputStream(content)));
			XMLFilter filtre2_2 = factory.newXMLFilter(new StreamSource(getClass().getResourceAsStream("/resources/schematron/show_errors.xsl")));

			filtre2_1.setParent(reader);
			filtre2_2.setParent(filtre2_1);

			SAXSource source2 = new SAXSource(filtre2_2, new InputSource(new FileInputStream(current_file)));
			StreamResult resultat2 = new StreamResult(writer);

			transformer.setOutputProperty("omit-xml-declaration", "yes");
			transformer.transform(source2, resultat2);

			//affichage du resultat
			String res = writer.toString("UTF-8");
			if (!res.trim().equals("")) {
				hadError = true;
				System.out.println(res);
			}

		} catch (Exception e) {
			hadError = true;
			System.out.println(e.getMessage());
		}
		return !(hadError);
	}
	/********************************************************************
	**   Test la conformite du fichier au profil
	*********************************************************************/
	private boolean profil_validation(File rng) {
		boolean hadError = false;
		try {
			ValidationDriver driver = new ValidationDriver();
			InputSource in = ValidationDriver.fileInputSource(rng);
			if (driver.loadSchema(in)) {
				if (!driver.validate(ValidationDriver.uriOrFileInputSource(current_file.getAbsolutePath())))
					hadError = true;
			} else
				hadError = true;
		} catch (SAXException e) {
			hadError = true;
			System.out.println("Erreur du parser "+e.getMessage());
		} catch (IOException e) {
			System.out.println("Erreur du parser "+e.getMessage());
			hadError = true;
		}
		return !(hadError);
	}

	/********************************************************************
	**   Applique une transformation XSL
	*********************************************************************/
	private void transform(File xsl) {
		try {
			SAXSource source = new SAXSource(new InputSource(new FileInputStream(current_file)));
			StreamResult result = new StreamResult(System.out);
			TransformerFactory factory = TransformerFactory.newInstance();
			Transformer transformer = factory.newTransformer(new StreamSource(new FileInputStream(xsl)));
			transformer.transform(source, result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/********************************************************************
	**   Test que toute les empreintes sont correctes
	*********************************************************************/
	private boolean hashcode_test() {
		boolean hadError = false;
		XMLReader parser = null;
		try {
			parser = XMLReaderFactory.createXMLReader();
			HashcodeContentHandler hashcodeContentHandler = new HashcodeContentHandler();
			parser.setContentHandler(hashcodeContentHandler);
			try {
				parser.parse(new InputSource(new FileInputStream(current_file)));
			} catch (SAXParseException e) {
				//Deja pris en charge par le ErrorHandler
			} catch (Exception e) {
				System.out.println("Erreur du parser - "+e.getMessage());
			}
			hadError = hashcodeContentHandler.hadError();
		} catch (Exception e) {
			hadError = true;
			System.out.println("Erreur: "+e+" - Impossible d'instancier le parser");
		}
		return !(hadError);
	}

	/********************************************************************
	**   Affiche les credits et la licence GPL
	*********************************************************************/
	public void about() {
		StringBuffer content = new StringBuffer();
		BufferedReader reader = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("/resources/COPYING.txt")));
		String line;
		try {
			while ((line=reader.readLine())!=null) {
				content.append(line).append("\n");
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		JPanel panel = new JPanel(new BorderLayout());
		String credits = "<html><p>Copyright (c) 2010 Minist�re de la Culture et de la Communication / " +
		"Service interminist�riel des archives de France / Sous-direction de la politique interminist�rielle et territoriale pour les archives traditionnelles et num�riques / Bureau des traitements et de la conservation</p><p></p>"+
		"<p>Contributeurs: <br><i>Michel Jacobson</i></p><p></p>"+
		"<p>Site web: <a href='http://www.archivesdefrance.culture.gouv.fr/seda/'>http://www.archivesdefrance.culture.gouv.fr/seda/</a></p></html>";
		panel.add(new JLabel(credits), BorderLayout.NORTH);
		JTextArea textArea = new JTextArea(content.toString());
		panel.add(new JScrollPane(textArea), BorderLayout.CENTER);
		panel.setPreferredSize(new Dimension(550, 500));
		JOptionPane.showConfirmDialog(this, panel, LABELS.getLocaliseString("label.about"), JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE);
	}

	/********************************************************************
	**   Recupere l'extension d'un fichier (a placer ailleur)
	*********************************************************************/
	public static String getExtension(File f) {
		String ext = null;
		String s = f.getName();
		int i = s.lastIndexOf('.');
		if (i > 0 &&  i < s.length() - 1) {
			ext = s.substring(i+1).toLowerCase();
		}
		return ext;
	}

	/********************************************************************
	**   Filtre pour fichiers
	*********************************************************************/
	private class MyFileFilter extends FileFilter {
		private String description = "All Files";
		private ArrayList extensions = new ArrayList();

		//Accepte les repertoires et les fichiers avec les extensions definies.
		public boolean accept(File f) {
			if (f.isDirectory()) {
				return true;
			}
			String extension = getExtension(f);
			if (extension != null) {
				if (extensions.contains(extension)) {
					return true;
				} else {
					return false;
				}
			}
			return false;
		}

		//Description du filtre
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public void addExtension(String extension) {
			extensions.add(extension);
		}
	}
	/********************************************************************
	**   HashcodeContentHandler
	*********************************************************************/
	private class HashcodeContentHandler extends DefaultHandler {
		private boolean hadError = false;
		private boolean integrity = false;
		private boolean attachment = false;
		private String algorithme = "";
		private String filename = "";

		public void startElement(String uri, String localName, String qName, Attributes attributes) {
			if ( (localName.equals("Integrity")) && (uri.equals("fr:gouv:culture:archivesdefrance:seda:v1.0")) ) {
				algorithme = attributes.getValue("algorithme");
				integrity = true;
			} else if ( (localName.equals("Attachment")) && (uri.equals("fr:gouv:culture:archivesdefrance:seda:v1.0")) ) {
				filename = attributes.getValue("filename");
				attachment = true;
			}
		}
		public void endElement(String uri, String localName, String qName) {
			if ( (localName.equals("Integrity")) && (uri.equals("fr:gouv:culture:archivesdefrance:seda:v1.0")) ) {
				integrity = false;
			} else if ( (attachment) && (localName.equals("Attachment")) && (uri.equals("fr:gouv:culture:archivesdefrance:seda:v1.0")) ) {
				attachment = false;
			}
		}
		public void characters(char[] ch, int start, int length) {
			if (integrity) {
				String empreinte = new String(ch, start, length);

				System.out.println("Test l'empreinte du fichier "+filename+": "+empreinte);

				String algo = "";
				if (algorithme.equals("http://www.w3.org/2000/09/xmldsig#sha1")) {
					algo = "SHA-1";
				} else if (algorithme.equals("http://www.w3.org/2001/04/xmlenc#sha256")) {
					algo = "SHA-256";
				} else if (algorithme.equals("http://www.w3.org/2001/04/xmlenc#sha512")) {
					algo = "SHA-512";
				}
				if (!algo.equals("")) {
					try {
						String compute = compute(new File(current_file.getParentFile(), filename), algo);
						if(!compute.equals(empreinte)) {
							System.out.println("   Erreur: valeur recalculee = "+compute);
							hadError = true;
						} else {
							System.out.println("   Ok");
						}
					} catch (Exception e) {
						hadError = true;
						System.out.println("   Erreur: "+e.getMessage());
					}
				} else {
					System.out.println("   Erreur: Algorithme inattendu "+algorithme+". Les algorithmes autorises sont: http://www.w3.org/2000/09/xmldsig#sha1, http://www.w3.org/2001/04/xmlenc#sha256 et http://www.w3.org/2001/04/xmlenc#sha512");
				}
			}
		}
		public boolean hadError() {
			return hadError;
		}

		/** Calcule l'empreinte d'un fichier et la retourne encodee en base64 **/
		public String compute(File inputfile, String algorithm) throws Exception {
		   FileInputStream fis = new FileInputStream(inputfile);
		   MessageDigest md = MessageDigest.getInstance(algorithm);
		   try {
			   DigestInputStream dis = new DigestInputStream(fis, md);
			   byte[] buffer = new byte[8192];
			   while(dis.read(buffer) != -1)
			   ;
		   } finally {
			   fis.close();
		   }
		   return Base64.encodeBase64String(md.digest());
		}
	}

	/********************************************************************
	**   SedaTransfertContentHandler
	*********************************************************************/
	private class SedaTransfertContentHandler extends DefaultHandler {
		private boolean isDocumentElement = false;
		private boolean hadError = false;

		public void startElement(String uri, String localName, String qName, Attributes attributes) {
			if (!isDocumentElement) {
				isDocumentElement = true;
				if ( (localName.equals("ArchiveTransfer")) && (uri.equals("fr:gouv:culture:archivesdefrance:seda:v1.0")) ) {
				} else {
					System.out.println("Warning: L'element racine {"+uri+"}"+localName+" ne correspond pas a un message de transfert");
				}
			}
		}
	}
	/********************************************************************
	**   SedaErrorHandler
	*********************************************************************/
	private class SedaErrorHandler extends DefaultHandler {
		private boolean hadError;

		public SedaErrorHandler() {
			super();
			hadError = false;
		}
		public boolean hadError() {
			return hadError;
		}
		public void warning(SAXParseException ex) throws SAXException {
			printError("Warning", ex);
		}
		public void error(SAXParseException ex) throws SAXException {
			hadError = true;
			printError("Error", ex);
		}
		public void fatalError(SAXParseException ex) throws SAXException {
			hadError = true;
			printError("Fatal Error", ex);
		}
		private void printError(String type, SAXParseException ex) {
			System.out.print("[");
			System.out.print(type);
			System.out.print("] ");
			if (ex== null) {
				System.out.print("!!!");
			}
			String systemId = ex.getSystemId();
			if (systemId != null) {
				int index = systemId.lastIndexOf('/');
				if (index != -1)
					systemId = systemId.substring(index + 1);
				System.out.print(systemId);
			}
			System.out.print(":");
			System.out.print(String.valueOf(ex.getLineNumber()));
			System.out.print(":");
			System.out.print(String.valueOf(ex.getColumnNumber()));
			System.out.print(": ");
			System.out.print(ex.getMessage());
			System.out.print("\n");
			//System.out.flush();
		}
	}
	private static class MyUriResolver implements URIResolver {
		public MyUriResolver() {
		}

		public Source resolve(String systemId, String base) {
			try {
				InputStream in = getClass().getResourceAsStream("/resources/schematron/" + systemId);
				return new StreamSource(in);
			} catch (Exception e) {
				System.out.println(e.getMessage());
				return null;
			}
		}
	}
};
