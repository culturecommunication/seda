/* ***** BEGIN LICENSE BLOCK *****
 *    Copyright 2011 Michel Jacobson michel.jacobson@gmail.com
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 * ***** END LICENSE BLOCK ***** */

/*-----------------------------------------------------------------------*/
package seda;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
/*-----------------------------------------------------------------------*/

public class Console extends JInternalFrame {
    private PipedInputStream     piOut, piErr;
    private PipedOutputStream    poOut, poErr;
    private JTextComponent       texte;

	/********************************************************************
	**   Redirection des sorties (System.out et System.err)
	**   dans l'editeur de texte d'une fenetre.
	*********************************************************************/
    public Console(JTextComponent texte) throws IOException {
		super("Console", true, false, false);
		try {
			setMaximum(true);
		} catch (Exception e) {
		}
		this.texte = texte;

        // Redirection de System.out
        piOut = new PipedInputStream();
        poOut = new PipedOutputStream(piOut);
        System.setOut(new PrintStream(poOut, true));//, "UTF-8"));

        // Redirection de System.err
        piErr = new PipedInputStream();
        poErr = new PipedOutputStream(piErr);
        System.setErr(new PrintStream(poErr, true));//, "UTF-8"));

        // Ajout de l'editeur de texte
        getContentPane().add(new JScrollPane(texte), BorderLayout.CENTER);

        // Lancement des threads
        new ReaderThread(piOut).start();
        new ReaderThread(piErr).start();
    }

	/********************************************************************
	**   Thread pour les sorties standard et erreur
	*********************************************************************/
    class ReaderThread extends Thread {
        PipedInputStream pi;

        ReaderThread(PipedInputStream pi) {
			super();
            this.pi = pi;
        }

        public void run() {
            try {
                while (true) {
		            final byte[] buf = new byte[1024];
                    final int len = pi.read(buf, 0, 1024);
                    if (len == -1) {
                        break;
                    }
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
							Document doc = texte.getDocument();
							try {
								doc.insertString(doc.getLength(), new String(buf, 0, len), null);
								texte.setCaretPosition(texte.getDocument().getLength());
							} catch(Exception e) {
							}
                        }
                    });
                }
            } catch (IOException e) {
            }
        }
    }
}
