Pour lancer l'application double-cliquez sur le fichier seda_toolkit.jar
Le code de l'application est dans le dossier src